enum EstadoUsuario {
  activo,
  inactivo,
  suspendido,
  eliminado,
}