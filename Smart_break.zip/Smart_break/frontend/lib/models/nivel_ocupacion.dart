enum NivelOcupacion {
  vacio,
  bajo, 
  medio,
  alto,
  lleno,
}