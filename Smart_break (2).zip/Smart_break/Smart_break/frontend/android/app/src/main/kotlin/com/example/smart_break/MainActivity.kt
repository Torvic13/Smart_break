package com.example.smart_break

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
